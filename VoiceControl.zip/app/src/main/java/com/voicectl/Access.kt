package com.voicectl

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class Access : AccessibilityService() {
    companion object { var i: Access? = null }

    override fun onServiceConnected() { i = this }
    override fun onUnbind(intent: Intent?): Boolean { i = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun w() = resources.displayMetrics.widthPixels
    fun h() = resources.displayMetrics.heightPixels

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 220) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }

    fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build(), null, null)
    }

    fun scroll(dir: String) {
        val W = w().toFloat(); val H = h().toFloat()
        when (dir) {
            "вниз" -> swipe(W / 2, H * 0.72f, W / 2, H * 0.28f)
            "вверх" -> swipe(W / 2, H * 0.28f, W / 2, H * 0.72f)
            "вправо" -> swipe(W * 0.8f, H / 2, W * 0.2f, H / 2)
            "влево" -> swipe(W * 0.2f, H / 2, W * 0.8f, H / 2)
        }
    }

    fun clickText(q: String): Boolean {
        val r = rootInActiveWindow ?: return false
        var best: AccessibilityNodeInfo? = null
        var bs = 0
        fun walk(x: AccessibilityNodeInfo?) {
            x ?: return
            if (x.isVisibleToUser) for (s in listOf(x.text, x.contentDescription)) {
                val l = Cmd.n(s?.toString() ?: "")
                if (l.isEmpty()) continue
                val sc = when { l == q -> 3; l.startsWith(q) -> 2; l.contains(q) -> 1; else -> 0 }
                if (sc > bs) { bs = sc; best = x }
            }
            for (k in 0 until x.childCount) walk(x.getChild(k))
        }
        walk(r)
        val x = best ?: return false
        var p: AccessibilityNodeInfo? = x
        while (p != null && !p.isClickable) p = p.parent
        if (p != null) return p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Rect(); x.getBoundsInScreen(b); tap(b.exactCenterX(), b.exactCenterY())
        return true
    }

    fun type(t: String, replace: Boolean = false): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val cur = if (replace || f.isShowingHintText) "" else (f.text?.toString() ?: "")
        val s = if (cur.isNotEmpty() && !cur.endsWith(" ") && t.isNotEmpty()) "$cur $t" else cur + t
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun enter(): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return Build.VERSION.SDK_INT >= 30 && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }
}
