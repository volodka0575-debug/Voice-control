package com.voicectl

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var orb: View
    private lateinit var st: TextView
    private lateinit var hd: TextView
    private lateinit var hint: TextView

    private fun tv(size: Float, color: Int) = TextView(this).apply {
        textSize = size; setTextColor(color); gravity = Gravity.CENTER
        setPadding(0, (12 * resources.displayMetrics.density).toInt(), 0, 0)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK)
            setPadding((24 * d).toInt(), 0, (24 * d).toInt(), 0)
        }
        orb = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF333333.toInt()) }
            layoutParams = LinearLayout.LayoutParams((150 * d).toInt(), (150 * d).toInt()).apply { bottomMargin = (36 * d).toInt() }
            setOnClickListener { tap() }
        }
        st = tv(24f, Color.WHITE); hd = tv(16f, 0xFF999999.toInt()); hint = tv(13f, 0xFF666666.toInt())
        listOf(orb, st, hd, hint).forEach { root.addView(it) }
        setContentView(root)
    }

    private fun missing(): String? = when {
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED -> "mic"
        Access.i == null -> "acc"
        !Settings.canDrawOverlays(this) -> "ovl"
        !Settings.System.canWrite(this) -> "wr"
        else -> null
    }

    private fun tap() {
        when (missing()) {
            "mic" -> requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS), 1)
            "acc" -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "ovl" -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            "wr" -> startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            else -> {
                val i = Intent(this, VoiceService::class.java)
                if (VoiceService.running) stopService(i) else startForegroundService(i)
                orb.postDelayed({ refresh() }, 300)
            }
        }
    }

    private fun refresh() {
        val m = missing()
        (orb.background as GradientDrawable).setColor(if (VoiceService.running) Color.WHITE else 0xFF333333.toInt())
        orb.scaleX = 1f; orb.scaleY = 1f
        st.text = when { m != null -> "Нажмите круг"; VoiceService.running -> "Слушаю"; else -> "Выключено" }
        hint.text = when (m) {
            "mic" -> "Шаг 1: разрешите микрофон, контакты, звонки"
            "acc" -> "Шаг 2: включите «Голос» в службах доступности"
            "ovl" -> "Шаг 3: разрешите показ поверх других окон"
            "wr" -> "Шаг 4: разрешите изменение настроек (яркость)"
            else -> "Круг — вкл/выкл"
        }
    }

    override fun onResume() {
        super.onResume()
        VoiceService.ui = { heard, res -> hd.text = if (heard.isEmpty()) "" else "«$heard»"; st.text = res }
        VoiceService.lvl = { v ->
            val sc = 1f + (v.coerceIn(0f, 10f) / 10f) * 0.6f
            orb.scaleX = orb.scaleX * 0.6f + sc * 0.4f; orb.scaleY = orb.scaleX
        }
        refresh()
    }

    override fun onPause() { VoiceService.ui = null; VoiceService.lvl = null; super.onPause() }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { refresh() }
}
