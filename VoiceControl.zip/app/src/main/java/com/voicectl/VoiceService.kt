package com.voicectl

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class VoiceService : Service(), RecognitionListener {
    companion object {
        var ui: ((String, String) -> Unit)? = null
        var lvl: ((Float) -> Unit)? = null
        var running = false
    }

    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null
    private val ri = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 600L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 450L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 250L)
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        Cmd.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("v", "Голосовое управление", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "v").setContentTitle("Слушаю команды").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "v:l").apply { acquire() }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { ui?.invoke("", "Нет сервиса распознавания (нужен Google)"); stopSelf(); return }
        create(); again(0)
    }

    private fun create() {
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
    }

    private fun again(ms: Long) {
        h.removeCallbacksAndMessages(null)
        h.postDelayed({
            if (running) try { sr?.startListening(ri) } catch (e: Exception) { create(); again(600) }
        }, ms)
    }

    override fun onResults(b: Bundle?) {
        val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        var res: String? = null
        for (x in l) {
            res = try { Cmd.run(this, x) } catch (e: Exception) { null }
            if (res != null) { ui?.invoke(x, res); break }
        }
        if (res == null) ui?.invoke(l.firstOrNull() ?: "", "—")
        again(0)
    }

    override fun onPartialResults(b: Bundle?) {
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { ui?.invoke(it, "…") }
    }

    override fun onError(e: Int) {
        when (e) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, 11, 12 -> { create(); again(700) }
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> again(30)
            else -> again(500)
        }
    }

    override fun onRmsChanged(v: Float) { lvl?.invoke(v) }
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(t: Int, p: Bundle?) {}

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
