package com.voicectl

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Cmd {
    var dictating = false
    private var torch = false
    private var tts: TextToSpeech? = null
    private var ttsOk = false

    fun init(c: Context) {
        if (tts == null) tts = TextToSpeech(c.applicationContext) {
            if (it == TextToSpeech.SUCCESS) { tts?.language = Locale("ru"); ttsOk = true }
        }
    }
    private fun say(s: String) { if (ttsOk) tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "v") }

    fun n(s: String) = s.lowercase().replace('ё', 'е').replace(Regex("[^a-zа-я0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }
    private fun arg(t: String, vararg p: String): String? {
        for (x in p) if (t.startsWith("$x ")) return t.substring(x.length + 1).trim()
        return null
    }
    private fun go(c: Context, i: Intent): Boolean = try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); true } catch (e: Exception) { false }
    private fun g(a: Access?, act: Int, m: String) = if (a != null && a.performGlobalAction(act)) m else "Включите службу доступности"

    /** Возвращает ответ, если команда распознана, иначе null. */
    fun run(c: Context, raw: String): String? {
        val t = n(raw)
        if (t.isEmpty()) return null
        val a = Access.i
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (dictating) {
            if (has(t, "стоп диктовка", "хватит диктовать", "конец диктовки", "закончить диктовку")) { dictating = false; return "Диктовка выключена" }
            return if (a?.type(raw.trim()) == true) "✎ ${raw.trim()}" else "Нет поля ввода"
        }
        Regex("^(напиши|напечатай|введи|печатай)\\s+(.+)", RegexOption.IGNORE_CASE).find(raw.trim())?.let {
            val x = it.groupValues[2]
            return if (a?.type(x) == true) "✎ $x" else "Нет поля ввода — нажмите на поле"
        }
        if (has(t, "режим диктовки", "начни диктовку", "диктуй")) { dictating = true; return "Диктовка: говорите текст" }
        if (has(t, "очисти поле", "удали все", "сотри все", "очисти текст")) { a?.type("", true); return "Поле очищено" }
        if (t in setOf("отправь", "отправить", "ввод", "энтер", "enter", "готово")) { a?.enter(); return "Enter" }

        if (t in setOf("назад", "вернись", "вернуться")) return g(a, AccessibilityService.GLOBAL_ACTION_BACK, "Назад")
        if (t in setOf("домой", "на главный экран", "главный экран", "домашний экран", "рабочий стол", "на рабочий стол")) return g(a, AccessibilityService.GLOBAL_ACTION_HOME, "Домой")
        if (has(t, "недавние", "последние приложения", "переключи приложение", "список приложений")) return g(a, AccessibilityService.GLOBAL_ACTION_RECENTS, "Недавние")
        if (has(t, "быстрые настройки")) return g(a, AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "Быстрые настройки")
        if (has(t, "уведомления", "шторка", "шторку")) return g(a, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Шторка")
        if (has(t, "скриншот", "снимок экрана")) return g(a, AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Скриншот")
        if (has(t, "заблокируй", "заблокировать", "блокировка экрана")) return g(a, AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Блокировка")
        if (has(t, "выключи телефон", "меню питания", "выключение")) return g(a, AccessibilityService.GLOBAL_ACTION_POWER_DIALOG, "Меню питания")
        if (has(t, "включи экран", "разбуди", "проснись")) {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            @Suppress("DEPRECATION")
            pm.newWakeLock(PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "v:w").acquire(3000)
            return "Экран включён"
        }

        Regex("^(прокрути |листай |скролл |свайп |промотай )?(вверх|вниз|влево|вправо)$").find(t)?.let {
            a?.scroll(it.groupValues[2]); return "Прокрутка ${it.groupValues[2]}"
        }
        arg(t, "нажми на", "нажми", "тапни", "кликни", "клик", "выбери")?.let { q ->
            return if (q in setOf("в центр", "по центру", "центр", "на центр")) { a?.let { it.tap(it.w() / 2f, it.h() / 2f) }; "Тап в центр" }
            else if (a?.clickText(q) == true) "Нажал «$q»" else "Не вижу «$q»"
        }

        if (has(t, "фонарик", "фонарь")) {
            val on = if (has(t, "выключи", "погаси", "выкл")) false else if (has(t, "включи", "зажги", "вкл")) true else !torch
            return try {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, on); torch = on
                if (on) "Фонарик включён" else "Фонарик выключен"
            } catch (e: Exception) { "Фонарик недоступен" }
        }

        if (has(t, "громк", "звук", "тише", "громче")) {
            val s = AudioManager.STREAM_MUSIC
            val mx = am.getStreamMaxVolume(s); val cur = am.getStreamVolume(s); val step = maxOf(1, mx / 8)
            val num = Regex("\\d+").find(t)?.value?.toIntOrNull()
            when {
                num != null -> am.setStreamVolume(s, mx * num.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
                has(t, "максимум", "на полную") -> am.setStreamVolume(s, mx, AudioManager.FLAG_SHOW_UI)
                has(t, "включи звук", "со звуком", "верни звук") -> am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                has(t, "без звука", "выключи звук", "беззвучн", "убери звук") -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                has(t, "тише", "потише", "убавь", "меньше", "уменьши") -> am.setStreamVolume(s, (cur - step).coerceAtLeast(0), AudioManager.FLAG_SHOW_UI)
                has(t, "громче", "погромче", "прибавь", "больше", "увеличь") -> am.setStreamVolume(s, (cur + step).coerceAtMost(mx), AudioManager.FLAG_SHOW_UI)
                else -> return null
            }
            return "Громкость"
        }

        if (has(t, "яркост", "ярче", "поярче", "темнее", "потемнее")) {
            if (!Settings.System.canWrite(c)) {
                go(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}")))
                return "Нужно разрешение на изменение настроек"
            }
            val cr = c.contentResolver
            val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
            val num = Regex("\\d+").find(t)?.value?.toIntOrNull()
            val v = when {
                num != null -> num.coerceIn(0, 100) * 255 / 100
                has(t, "максимум", "на полную") -> 255
                has(t, "минимум") -> 5
                has(t, "меньше", "темнее", "потемнее", "убавь", "ниже") -> cur - 40
                has(t, "больше", "ярче", "поярче", "прибавь", "выше") -> cur + 40
                else -> return null
            }
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v.coerceIn(1, 255))
            return "Яркость"
        }

        Regex("будильник на (\\d{1,2})(?: (\\d{1,2}))?").find(t)?.let { m ->
            val hh = m.groupValues[1].toInt(); val mm = m.groupValues[2].toIntOrNull() ?: 0
            go(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hh).putExtra(AlarmClock.EXTRA_MINUTES, mm).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Будильник $hh:${"%02d".format(mm)}"
        }
        Regex("таймер на (\\d+) (секунд|минут|час)").find(t)?.let { m ->
            val k = m.groupValues[1].toInt() * when (m.groupValues[2]) { "секунд" -> 1; "минут" -> 60; else -> 3600 }
            go(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, k).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Таймер $k сек"
        }

        arg(t, "позвони", "набери", "вызови", "звони")?.let { q ->
            val d = q.replace(" ", "")
            val num = if (d.length >= 3 && d.all { it.isDigit() }) d else contact(c, q)
            if (num == null) return "Контакт не найден: $q"
            val ok = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            go(c, Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
            return "Звоню: $q"
        }
        arg(t, "найди", "загугли", "поищи", "найти", "погугли")?.let { q ->
            go(c, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)); return "Ищу: $q"
        }

        val mk = when {
            has(t, "следующий трек", "следующая песня") -> KeyEvent.KEYCODE_MEDIA_NEXT
            has(t, "предыдущий трек", "предыдущая песня", "прошлый трек") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            t in setOf("пауза", "поставь на паузу", "играй", "продолжи", "воспроизведи", "стоп музыка", "включи музыку") -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            else -> null
        }
        if (mk != null) {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, mk)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, mk)); return "Медиа"
        }

        if (has(t, "который час", "сколько времени")) { val s = SimpleDateFormat("H:mm", Locale("ru")).format(Date()); say(s); return s }
        if (has(t, "заряд", "батаре")) {
            val p = (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            say("Заряд $p процентов"); return "Заряд $p%"
        }

        // Системные переключатели: Android не даёт включать их тихо — открываем нужную панель
        val st = when {
            has(t, "мобильные данные", "мобильный интернет") -> Settings.ACTION_DATA_ROAMING_SETTINGS
            has(t, "вайфай", "вай фай", "wifi", "wi fi") -> "android.settings.panel.action.INTERNET_CONNECTIVITY"
            has(t, "блютуз", "блютус", "bluetooth") -> Settings.ACTION_BLUETOOTH_SETTINGS
            has(t, "режим полета", "авиарежим", "в самолете") -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            has(t, "геолокац", "гпс", "gps", "местоположение") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            has(t, "не беспокоить") -> Settings.ACTION_SOUND_SETTINGS
            else -> null
        }
        if (st != null) {
            if (!go(c, Intent(st))) go(c, Intent(Settings.ACTION_WIRELESS_SETTINGS))
            return "Открыл панель — скажите «нажми …»"
        }

        arg(t, "открой", "запусти", "включи", "открыть", "запустить", "зайди в", "перейди в", "покажи")?.let { return openApp(c, it) }
        return null
    }

    private fun contact(c: Context, q: String): String? {
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val stem = if (q.length > 3) q.dropLast(1) else q
        val P = ContactsContract.CommonDataKinds.Phone
        c.contentResolver.query(P.CONTENT_URI, arrayOf(P.DISPLAY_NAME, P.NUMBER), null, null, null)?.use { cu ->
            while (cu.moveToNext()) if (n(cu.getString(0) ?: "").contains(stem)) return cu.getString(1)
        }
        return null
    }

    private val alias = mapOf(
        "ютуб" to "youtube", "вотсап" to "whatsapp", "ватсап" to "whatsapp", "вацап" to "whatsapp", "телега" to "telegram",
        "телеграм" to "telegram", "хром" to "chrome", "гугл" to "google", "карты" to "maps", "почта" to "gmail",
        "камера" to "camera", "галерея" to "gallery", "фото" to "photos", "часы" to "clock", "калькулятор" to "calculator",
        "плей маркет" to "play store", "вк" to "vk", "контакты" to "contacts", "телефон" to "phone", "сообщения" to "messages",
        "настройки" to "settings", "музыка" to "music", "заметки" to "notes", "календарь" to "calendar", "файлы" to "files",
        "тикток" to "tiktok", "инстаграм" to "instagram", "яндекс" to "yandex"
    )

    private fun openApp(c: Context, q0: String): String? {
        val pm = c.packageManager
        val apps: List<ResolveInfo> = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val qs = listOfNotNull(q0, alias[q0], tr(q0))
        var best: ResolveInfo? = null; var bs = 0
        for (r in apps) {
            val l = n(r.loadLabel(pm).toString()); val p = r.activityInfo.packageName
            var s = 0
            for (q in qs) {
                val sc = when {
                    l == q -> 100
                    q.length >= 3 && (l.startsWith(q) || (l.length >= 3 && q.startsWith(l))) -> 90
                    q.length >= 3 && (l.contains(q) || p.contains(q.replace(" ", ""))) -> 80
                    lev(l, q) <= maxOf(1, q.length / 4) -> 60
                    else -> 0
                }
                if (sc > s) s = sc
            }
            if (s > bs) { bs = s; best = r }
        }
        val b = best ?: return null
        val i = pm.getLaunchIntentForPackage(b.activityInfo.packageName) ?: return null
        return if (go(c, i)) "Открываю ${b.loadLabel(pm)}" else null
    }

    private fun tr(s: String): String {
        val ru = "абвгдежзийклмнопрстуфхцчшщъыьэюя"
        val la = arrayOf("a", "b", "v", "g", "d", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "f", "h", "c", "ch", "sh", "sh", "", "y", "", "e", "yu", "ya")
        return s.map { val i = ru.indexOf(it); if (i >= 0) la[i] else it.toString() }.joinToString("")
    }

    private fun lev(a: String, b: String): Int {
        var p = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val q = IntArray(b.length + 1); q[0] = i
            for (j in 1..b.length) q[j] = minOf(p[j] + 1, q[j - 1] + 1, p[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            p = q
        }
        return p[b.length]
    }
}
